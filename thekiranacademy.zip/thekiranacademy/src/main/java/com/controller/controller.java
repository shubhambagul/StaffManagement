package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.model.staff;
import com.service.service;

@RestController
public class controller {
    @Autowired
    service sr;
	@PostMapping("/insert")
	public boolean postrecord(@RequestBody staff s ) {
		boolean post = sr.postrecord(s);
		return post;
	}
	@GetMapping("/all")
	public List<staff> getrecord () {
		List<staff>l =	sr.getrecord();
		return l;
	}
	@GetMapping("/select/{id}")
	public staff selectrecord(@PathVariable int id) {
	staff ss =	sr.selectrecord(id);
	return ss;
	}
	@GetMapping("/salary")
	public List<staff> getsalary() {
		List<staff>l =	sr.getsalary();
		return l;
	}
	@GetMapping("/experiance")
	public List<staff> getexperiance() {
		List<staff>l =	sr.getexperiance();
		return l;
	}
	@GetMapping("/maxsalary")
	public List<staff> getmaxsalary() {
		List<staff>l=sr.getmaxsalary();
		return l;
		
	}
	@PutMapping("/updatesalary")
	public boolean updatesalary(@RequestBody staff s) {
	boolean b =	sr.updatesalary(s);
	return b;
	}
	@GetMapping("/equal")
	public List<staff> equalprofile() {
		List<staff>l=sr.equalprofile();
		return l;
	}
	@GetMapping("/notequal")
	public List<staff> notequalprofile() {
		List<staff>l=sr.notequalprofile();
		return l;
}
}














