package com.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.staff;
@Repository
public class dao {
   @Autowired
     SessionFactory sf;
	public boolean postrecord(staff s) {
	Session session =	sf.openSession();
		Transaction tr = session.beginTransaction();
		System.out.println(s);
		session.save(s);
		tr.commit();
		sf.close();
		return true;
		
	}
	public List<staff> getrecord() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(staff.class);
		List<staff>l=criteria.list();
		System.out.println(l);
		sf.close();
		return l;
	}
	public staff selectrecord(int id) {
		Session session = sf.openSession();
	staff ss =	session.get(staff.class, id);
		sf.close();
		return ss;
		
	}
	public List<staff> getsalary() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(staff.class);
		criteria.add(Restrictions.gt("salary", 20000));
		List<staff>l=criteria.list();
		System.out.println(l);
		
	/*	for(staff ss : l) {
			System.out.println(ss);
		}*/
		sf.close();
		return l;
		
	}
	public List<staff> getexperiance() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(staff.class);
		criteria.add(Restrictions.between("experience", 10, 20));
		List<staff>l=criteria.list();
		System.out.println(l);
		sf.close();
		return l;
	}
	public List<staff> getmaxsalary() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(staff.class);
		criteria.addOrder(Order.desc("salary"));
		criteria.setMaxResults(1);
		List<staff>l=criteria.list();
		System.out.println(l);
		sf.close();
		return l;
		
	}
	public boolean updatesalary(staff s) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		System.out.println(s);
		session.update(s);
		tr.commit();
		sf.close();
		return true;
	}
	public List<staff> equalprofile() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(staff.class);
		criteria.add(Restrictions.eq("profile", "trainer"));
		List<staff>l=criteria.list();
		System.out.println(l);
		sf.close();
		return l;
	}
	public List<staff> notequalprofile() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(staff.class);
		criteria.add(Restrictions.ne("profile", "trainer"));
		List<staff>l=criteria.list();
		System.out.println(l);
		sf.close();
		return l;
	}
}
	
	
	
	
	
	







