package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.dao;
import com.model.staff;
@Service
public class service {
	@Autowired
    dao d;
	public boolean postrecord(staff s) {
		return d.postrecord(s);
		
	}
	public List<staff> getrecord() {
		return d.getrecord();
		
	}
	public staff selectrecord(int id) {
		return d.selectrecord(id);
		
	}
	public List<staff> getsalary() {
		return d.getsalary();
		
	
	}
	public List<staff> getexperiance() {
		return d.getexperiance();
		
	}
	public List<staff> getmaxsalary() {
	return d.getmaxsalary();
		
	}
	public boolean updatesalary(staff s) {
		return d.updatesalary(s);
		
	}
	public List<staff> equalprofile() {
		return d.equalprofile();
		
	}
	public List<staff> notequalprofile() {
		return d.notequalprofile();
	}
}






